
CREATE VIEW [Person].[vStateProvinceCountryRegion] 
WITH SCHEMABINDING 
AS 
SELECT 
    sp.[StateProvinceID] 
    ,sp.[StateProvinceCode] 
    ,sp.[IsOnlyStateProvinceFlag] 
    ,sp.[Name] AS [StateProvinceName] 
    ,sp.[TerritoryID] 
    ,cr.[CountryRegionCode] 
    ,cr.[Name] AS [CountryRegionName]
FROM [Person].[StateProvince] sp 
    INNER JOIN [Person].[CountryRegion] cr 
    ON sp.[CountryRegionCode] = cr.[CountryRegionCode];
GO
DECLARE @sn NVARCHAR(30)
SET @sn = schema_name()
EXECUTE sp_addextendedproperty N'MS_Description', N'Joins StateProvince table with', N'SCHEMA', @sn, N'VIEW',
                               N'vStateProvinceCountryRegion'
GO
DECLARE @sn NVARCHAR(30)
SET @sn = schema_name()
EXECUTE sp_addextendedproperty N'MS_Description', N'Clustered index on the view vS', N'SCHEMA', @sn, N'VIEW',
                               N'vStateProvinceCountryRegion', N'COLUMN', N'StateProvinceID'
GO
